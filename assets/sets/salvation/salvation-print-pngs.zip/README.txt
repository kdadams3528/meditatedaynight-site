SALVATION — PAGE-ONLY EDITION (V3)
Prepared November 6, 2026 (CST).

SOLE SELECTION SOURCE
https://peacewithgod.net/steps/
The exact page was retrieved live with WebFetch and curl during this revision.
All 13 Scripture references and the prayer were selected ONLY from this page,
in its displayed order. No earlier set, Romans Road source, or other salvation
presentation supplied any additional verse or prayer wording.
The local HTML/text snapshot is retained in sources/ for verification, not
included in the production ZIP. No source-page explanatory prose is used.

REFERENCE INVENTORY — ONE COMPLETE INDIVIDUAL VERSE PER SIDE
Step 1: Romans 5:1; John 3:16; John 10:10.
Step 2: Romans 3:23; Romans 6:23; Proverbs 14:12; Isaiah 59:2.
Step 3: 1 Timothy 2:5; 1 Peter 3:18; Romans 5:8.
Step 4: Revelation 3:20; John 1:12; Romans 10:9.
The extracted source inventory exactly matches these 13 references; there are
no multi-verse citations on this page and none of these references repeats.

PHYSICAL CARD COUNT
8 content cards, plus 2 separate cover artworks:
Cards 1–6: one complete verse on Front and one complete verse on Back.
Card 7: Romans 10:9 on Front; Back intentionally blank.
Card 8: the source prayer, complete, Front and Back of ONE physical card.
Total: 13 Scripture sides + 1 blank side + 2 prayer sides + 2 covers = 18 PNGs.
Covers now match the approved Meditate Day & Night standard set covers.
The front has the ministry logo, Scripture Wallet and Salvation below the band,
with clear line separation and NO website address. The approved generic back
contains Psalm 1:2 and the ministry website; these are COVER ONLY, not additions
to the 13 salvation verses selected from the requested page.
No official endorsement is implied.

LARGE PRINT
86 x 54 mm landscape, 2031 x 1276 pixels, 600 DPI; pure 1-bit black/white.
Crimson Text SemiBold justified body; SemiBold Italic citations.
Scripture body: consistent 136 px / 16.32 pt. This is the largest common whole-
pixel size that fits all 13 complete verses in the existing production margins,
line pitch and citation treatment without shrinking. It is 7.9% larger than
the previous 126 px Salvation body and 21.4% above the 112 px old standard.
Prayer body: consistent 126 px / 15.12 pt on both sides; it remains large print.
Navigation headings and side-number footers use 44 px; they are not body text.
No content side automatically shrinks. Covers have independent title typography.

PRAYER HANDLING — EXACT SOURCE WORDING
The page's prayer contains 80 whitespace-delimited words (not the 81 words in
the older source). The new source omits a word present in that earlier prayer;
this version uses the NEW page exactly. Its straight apostrophe is preserved.
The prayer is explicitly identified as prayer, not a Bible verse.
Card 8 Front contains the first 43 words; Back contains the remaining 37 words.
The sentence boundary before the request for Christ's indwelling is the turn.
Joining Front and Back with a space exactly reproduces the source prayer,
normalizing source whitespace only. It is within the 90-word prose allowance.
The full prayer does NOT fit a single SIDE at the readable old-standard 112 px,
so using both sides of one physical card avoids tiny type. At the chosen
sentence split, 126 px is the maximum common size for the two prayer sides.
No newly composed, adapted, shortened, or older prayer was substituted.

KJV TEXT ACCURACY — NOT ADDITIONAL SELECTION SOURCES
The website displays modern-English translations and sometimes partial verses.
Kevin's standing KJV preference is used here for the COMPLETE text of each
selected verse, including portions not reproduced in the site's short quotes.
KJV words were loaded from the existing verified eBible KJV corpus and
independently cross-checked lexically against the local Project Gutenberg KJV.
These corpora were used solely to verify verse TEXT, never to choose verses.
https://ebible.org/kjv/
https://www.gutenberg.org/ebooks/10
No Bible words, verse endings or punctuation were removed, no ellipses inserted,
and no individual verse was split or combined with another verse on a side.

FILES
Salvation Page-Only Review.pdf: actual-size review; print Actual Size / 100%.
  Paired logical Front/Back review sheets, NOT duplex-imposed print artwork.
Salvation Page-Only PNGs.zip: all 18 PNGs, editable manifests, source notes,
  selection/fit record and validation results. No full source-page reproduction.
PNGs/: separate LightBurn-compatible numbered Front/Back artwork and covers.
Contact Sheet.png: preview of all sides; not production engraving artwork.
preview-1.png through preview-3.png: paged previews of every side.
content.json / content.csv: editable complete text, references, sequence and URL.
selection.json: extracted page inventory, exact prayer, and per-passage fit limits.
validation.json: dimensions, unchanged text, full-size fit, numbering and bounds.
build.py / fit.py: local rendering and source-inventory validation scripts.

QUALITY CHECKS
All 18 PNGs visually inspected: no text clipping or overlapping elements.
All content sides fit at the declared full size; ink bounds stay inside the card.
All 13 KJV verses passed independent lexical cross-checking.
All Scripture citations match the exact source-page inventory and order.
All Scripture sides contain exactly one verse.
Both prayer sides belong to Card 8; their concatenation matches the new source.
PNG dimensions, 1-bit mode, DPI and ZIP integrity verified.
No old sets, websites, laser settings, external messages or print jobs changed.
No LightBurn project or machine settings were generated or modified.

SAVED EDITION: standard branded covers added at Kevin’s request. All 16 card
Front/Back PNGs are byte-identical to the approved page-only v3 edition.
Outlined SVG covers contain paths, not live fonts, at 86 x 54 mm.
Drive destination: Ministry / Salvation, beside Word Faith Transformation
and the other established scripture-wallet sets. Individual PNGs in print-png.
