SALVATION — SCRIPTURE CARDS (updated 2026-11-19)
8 cards, 14 complete KJV verses and one prayer card, plus front and back covers.
Cards 1–7: one complete KJV verse on each side. Card 7 back: Romans 10:10.
Card 8: the salvation prayer (not Scripture), front and back.
Verses and prayer from https://peacewithgod.net/steps/, with Romans 10:10 added. No endorsement is implied.
86 x 54 mm, 2031 x 1276 px, 600 DPI, 1-bit black and white. Scripture 16.32 pt; prayer 15.12 pt.
Front cover: set name only. Back cover: Psalm 1:2 and MeditateDayNight.com.
Contact: Claremore, Oklahoma · (918) 230-9513 · info@meditatedaynight.com
